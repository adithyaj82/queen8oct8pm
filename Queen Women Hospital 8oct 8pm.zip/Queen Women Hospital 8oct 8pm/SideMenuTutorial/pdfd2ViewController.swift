//
//  pdfd2ViewController.swift
//  Queen Women Hospital
//
//  Created by adithya on 9/15/18.
//  Copyright © 2018 Kyle Suchar. All rights reserved.
//

import UIKit

class pdfd2ViewController: UIViewController {
    @IBOutlet weak var myWebView: UIWebView!

    let pdfTitles = "healthIssues"

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        if let url = Bundle.main.url(forResource: pdfTitles, withExtension: "pdf") {
            
            let urlRequest = URLRequest(url: url)
            myWebView.loadRequest(urlRequest as URLRequest)
       
        }
    }


}
