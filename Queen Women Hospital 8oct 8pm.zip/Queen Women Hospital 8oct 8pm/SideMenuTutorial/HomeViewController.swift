//
//  ViewController.swift
//  SideMenuTutorial
//
//  Created by Kyle Suchar on 3/9/17.
//  Copyright © 2017 Kyle Suchar. All rights reserved.
//

import UIKit
class HomeViewController: UITableViewController {

    @IBOutlet weak var menuButton: UIBarButtonItem!
    override func viewDidLoad() {
        super.viewDidLoad()
        sideMenus()
        customizeNavBar()
        // Do any additional setup after loading the view.
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    override var preferredStatusBarStyle: UIStatusBarStyle{
        return UIStatusBarStyle.lightContent
    }
    
    func sideMenus() {
        
        if revealViewController() != nil {
            
            menuButton.target = revealViewController()
            menuButton.action = #selector(SWRevealViewController.revealToggle(_:))
            revealViewController().rearViewRevealWidth = 275
           // revealViewController().rightViewRevealWidth = 160
            
//
//            alertButton.target = revealViewController()
//            alertButton.action = #selector(SWRevealViewController.rightRevealToggle(_:))
//
//
            view.addGestureRecognizer(self.revealViewController().panGestureRecognizer())
            
        }
        
        
    }

    func customizeNavBar() {
        
        navigationController?.navigationBar.tintColor = UIColor(displayP3Red: 255/255, green: 255/255, blue: 255/255, alpha: 1)
        navigationController?.navigationBar.barTintColor = UIColor(displayP3Red: 167/255, green: 55/255, blue: 140/255, alpha: 1)
        
      
        navigationController?.navigationBar.titleTextAttributes = [NSForegroundColorAttributeName: UIColor.white]
        
        
    }
    
    @IBAction func share(_ sender: Any) {

            let activityVC = UIActivityViewController(activityItems: ["https://play.google.com/store/apps/details?id=com.nirvanza.pediatrichospital"], applicationActivities: nil)
            activityVC.popoverPresentationController?.sourceView = self.view
            self.present(activityVC, animated: true, completion: nil)
            
        
    }
    @IBAction func gallery(_ sender: Any) {
    
    }
    
}
