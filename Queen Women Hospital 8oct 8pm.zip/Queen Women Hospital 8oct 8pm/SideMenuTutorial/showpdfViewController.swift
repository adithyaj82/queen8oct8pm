//
//  showpdfViewController.swift
//  Queen Women Hospital
//
//  Created by adithya on 9/15/18.
//  Copyright © 2018 Kyle Suchar. All rights reserved.
//

import UIKit

class showpdfViewController: UIViewController {

    @IBOutlet var h1: UIView!
    @IBOutlet var h2: UIView!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func womanissue(_ sender: Any) {
        h1.isHidden = true
        h2.isHidden = false

//        let vc  = self.storyboard?.instantiateViewController(withIdentifier: "pdfdetailController")as! pdfdetailController
         //   vv = "issue"
//        self.navigationController?.pushViewController(vc, animated: true)
//
//
    }
    @IBAction func openPDFAction(_ sender: Any) {
        h1.isHidden = false
        h2.isHidden = true

//        let vc  = self.storyboard?.instantiateViewController(withIdentifier: "pdfdetailController")as! pdfdetailController
//vv = "healthIssue"
//        self.navigationController?.pushViewController(vc, animated: true)

        
        }
        

}
